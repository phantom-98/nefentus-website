const t="_contact_1gzi0_1",o="_bgImage_1gzi0_5",c="_description_1gzi0_32",n="_buttonWrapper_1gzi0_40",s={contact:t,bgImage:o,description:c,buttonWrapper:n};export{s};
