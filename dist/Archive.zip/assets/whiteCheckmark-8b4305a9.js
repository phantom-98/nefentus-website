const s="/assets/whiteCheckmark-c6f064cb.svg";export{s as C};
